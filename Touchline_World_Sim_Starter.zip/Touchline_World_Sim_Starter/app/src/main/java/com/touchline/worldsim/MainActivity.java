package com.touchline.worldsim;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  WebView v = new WebView(this); v.setWebViewClient(new WebViewClient());
  v.getSettings().setJavaScriptEnabled(true); v.getSettings().setDomStorageEnabled(true);
  setContentView(v); v.loadUrl("file:///android_asset/index.html");
 }
}
